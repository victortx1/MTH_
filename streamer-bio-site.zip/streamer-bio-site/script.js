(() => {
  "use strict";
  const config = window.STREAMER_CONFIG || {};
  const byId = (id) => document.getElementById(id);
  const safeText = (value, fallback = "") => typeof value === "string" ? value : fallback;
  const validUrl = (value) => {
    try {
      const parsed = new URL(value, window.location.href);
      return (parsed.protocol === "https:" || parsed.protocol === "http:") ? parsed.href : null;
    } catch (_) { return null; }
  };

  const name = safeText(config.name, "SEU NOME");
  byId("brand-name").textContent = safeText(config.brand, name);
  byId("hero-name").textContent = name;
  byId("status-label").textContent = safeText(config.status, "CRIADOR DE CONTEÚDO");
  byId("bio").textContent = safeText(config.bio);
  byId("about-text").textContent = safeText(config.about);
  byId("footer-copy").textContent = `© ${new Date().getFullYear()} — ${name}. Todos os direitos reservados.`;
  const mainLink = validUrl(safeText(config.mainLink, "#links"));
  if (mainLink) byId("main-live").href = mainLink;

  const grid = byId("link-grid");
  const links = Array.isArray(config.links) ? config.links : [];
  links.forEach((item, index) => {
    if (!item || typeof item !== "object") return;
    const url = validUrl(item.url);
    if (!url) return;
    const card = document.createElement("a");
    card.className = "link-card";
    card.href = url;
    card.target = "_blank";
    card.rel = "noopener noreferrer";
    card.setAttribute("aria-label", `${safeText(item.title, "Link")} — abrir em nova aba`);

    const icon = document.createElement("span");
    icon.className = "link-icon";
    icon.textContent = safeText(item.icon, "↗");
    const content = document.createElement("span");
    content.className = "link-content";
    const title = document.createElement("strong");
    title.textContent = safeText(item.title, "Minha plataforma");
    const desc = document.createElement("small");
    desc.textContent = safeText(item.description);
    const label = document.createElement("span");
    label.className = "link-label";
    label.textContent = safeText(item.label, "ACESSAR");
    const arrow = document.createElement("span");
    arrow.className = "link-arrow";
    arrow.textContent = "↗";

    content.append(title, desc);
    card.append(icon, content, label, arrow);
    card.style.setProperty("--card-index", String(index));
    grid.append(card);
  });
  if (!grid.children.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "Adicione seus links no arquivo config.js.";
    grid.append(empty);
  }
})();
