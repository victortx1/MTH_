/*
  PERSONALIZE ESTE ARQUIVO:
  1. Troque nome, bio e textos.
  2. Substitua os links de exemplo pelos endereços oficiais.
  3. Para remover um cartão, apague o objeto correspondente da lista.
*/
window.STREAMER_CONFIG = {
  name: "SEU NOME",
  brand: "STREAMER",
  status: "AO VIVO / CRIADOR DE CONTEÚDO",
  bio: "Lives, jogos, resenhas e conteúdo. Encontre aqui todas as minhas plataformas e projetos oficiais.",
  about: "Este é meu espaço oficial. Aqui você encontra meus canais, redes sociais, projetos e novidades em um só lugar. Chega mais!",
  mainLink: "#links",
  links: [
    { title: "Twitch", description: "Acompanhe minhas transmissões ao vivo.", url: "https://twitch.tv/", icon: "◉", label: "LIVE" },
    { title: "YouTube", description: "Vídeos, cortes e conteúdos especiais.", url: "https://youtube.com/", icon: "▶", label: "VÍDEOS" },
    { title: "Instagram", description: "Bastidores, fotos e novidades.", url: "https://instagram.com/", icon: "◎", label: "SOCIAL" },
    { title: "TikTok", description: "Clipes e momentos das lives.", url: "https://tiktok.com/", icon: "♪", label: "CLIPES" },
    { title: "Discord", description: "Faça parte da comunidade.", url: "https://discord.com/", icon: "⌘", label: "COMUNIDADE" },
    { title: "Meu site", description: "Conheça meus projetos e novidades.", url: "https://example.com/", icon: "↗", label: "SITE OFICIAL" }
  ]
};
